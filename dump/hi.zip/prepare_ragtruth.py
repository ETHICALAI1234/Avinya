#!/usr/bin/env python3
"""
TrustLens — RAGTruth preprocessing.

Normalises RAGTruth into ONE flat schema usable directly by the FLOW-07
verdict engine and the FLOW-15 benchmark. Handles the source_info shape
difference across task types (dict for QA/Data2txt, str for Summary).

Usage:
    git clone --depth 1 https://github.com/ParticleMedia/RAGTruth.git
    python prepare_ragtruth.py --raw RAGTruth/dataset --out data/processed
"""
import json, argparse, pathlib, random, collections

SEED = 42


def normalise_context(src: dict) -> tuple[str, str]:
    """Return (question, context_text) for any task type.

    QA       -> source_info = {question, passages}
    Summary  -> source_info = str (the document)
    Data2txt -> source_info = dict of structured business fields
    """
    task = src.get("task_type")
    info = src.get("source_info")

    if task == "QA" and isinstance(info, dict):
        return info.get("question", ""), info.get("passages", "")

    if task == "Summary":
        return "Summarise the following document.", info if isinstance(info, str) else json.dumps(info)

    if task == "Data2txt" and isinstance(info, dict):
        # flatten the structured record into readable text the verifier can read
        parts = []
        for k, v in info.items():
            if v is None or v == "":
                continue
            if isinstance(v, (dict, list)):
                v = json.dumps(v, ensure_ascii=False)
            parts.append(f"{k}: {v}")
        return "Write an overview of this business.", "\n".join(parts)

    # fallback: never crash on an unexpected shape
    return src.get("prompt", ""), info if isinstance(info, str) else json.dumps(info)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="RAGTruth/dataset")
    ap.add_argument("--out", default="data/processed")
    ap.add_argument("--slice-size", type=int, default=100)
    args = ap.parse_args()

    raw = pathlib.Path(args.raw)
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    sources = {}
    for line in (raw / "source_info.jsonl").open(encoding="utf-8"):
        s = json.loads(line)
        sources[s["source_id"]] = s

    rows, dropped, offset_bad = [], 0, 0
    for line in (raw / "response.jsonl").open(encoding="utf-8"):
        r = json.loads(line)
        src = sources.get(r["source_id"])
        if src is None:
            dropped += 1
            continue

        # RAGTruth marks degenerate generations; exclude them from eval
        if r.get("quality") != "good":
            dropped += 1
            continue

        question, context = normalise_context(src)
        answer = r["response"]

        spans = []
        for lb in (r.get("labels") or []):
            st, en = lb["start"], lb["end"]
            # verify the offsets actually index THIS answer string
            if not (0 <= st < en <= len(answer)) or answer[st:en] != lb.get("text", answer[st:en]):
                offset_bad += 1
                continue
            spans.append({
                "start": st,
                "end": en,
                "text": answer[st:en],
                "label_type": lb.get("label_type"),      # Evident/Subtle x Conflict/Baseless Info
                "severity": "evident" if str(lb.get("label_type", "")).startswith("Evident") else "subtle",
                "kind": "conflict" if "Conflict" in str(lb.get("label_type", "")) else "baseless_info",
                "meta": lb.get("meta"),
            })

        rows.append({
            "id": r["id"],
            "split": r.get("split"),
            "task_type": src.get("task_type"),
            "model": r.get("model"),
            "question": question,
            "context": context,
            "answer": answer,
            "spans": spans,
            "has_hallucination": len(spans) > 0,
            "n_spans": len(spans),
        })

    print(f"joined {len(rows)} rows (dropped {dropped}, bad offsets {offset_bad})")

    # ---- write splits -------------------------------------------------
    for split in ("train", "test"):
        subset = [r for r in rows if r["split"] == split]
        path = out / f"ragtruth_{split}.jsonl"
        with path.open("w", encoding="utf-8") as f:
            for r in subset:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        pos = sum(r["has_hallucination"] for r in subset)
        print(f"{split:5s}: {len(subset):6d} rows | hallucinated {pos} ({pos/max(len(subset),1):.1%})")

    # ---- balanced eval slice from TEST only ---------------------------
    random.seed(SEED)
    test = [r for r in rows if r["split"] == "test"]
    pos = [r for r in test if r["has_hallucination"]]
    neg = [r for r in test if not r["has_hallucination"]]
    k = min(args.slice_size // 2, len(pos), len(neg))
    sl = random.sample(pos, k) + random.sample(neg, k)
    random.shuffle(sl)

    with (out / "eval_slice.jsonl").open("w", encoding="utf-8") as f:
        for r in sl:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    with (out / "dev_slice.jsonl").open("w", encoding="utf-8") as f:
        for r in sl[:10]:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"eval_slice: {len(sl)} rows ({k} hallucinated / {k} clean)")

    # ---- demo cases: clean, evident, subtle ---------------------------
    def pick(pred):
        return next((r for r in test if pred(r) and len(r["context"]) < 3500
                     and len(r["answer"]) < 1200), None)

    demo = {
        "clean":   pick(lambda r: not r["has_hallucination"]),
        "evident": pick(lambda r: any(s["severity"] == "evident" for s in r["spans"])),
        "subtle":  pick(lambda r: any(s["severity"] == "subtle" for s in r["spans"])),
    }
    json.dump({k: v for k, v in demo.items() if v},
              (out / "demo_cases.json").open("w", encoding="utf-8"),
              indent=2, ensure_ascii=False)
    print("demo_cases:", [k for k, v in demo.items() if v])

    stats = {
        "total_rows": len(rows),
        "by_split": dict(collections.Counter(r["split"] for r in rows)),
        "by_task": dict(collections.Counter(r["task_type"] for r in rows)),
        "by_model": dict(collections.Counter(r["model"] for r in rows)),
        "total_spans": sum(r["n_spans"] for r in rows),
        "label_types": dict(collections.Counter(
            s["label_type"] for r in rows for s in r["spans"])),
        "seed": SEED,
    }
    json.dump(stats, (out / "stats.json").open("w"), indent=2)
    print("\nwrote:", ", ".join(sorted(p.name for p in out.iterdir())))


if __name__ == "__main__":
    main()
