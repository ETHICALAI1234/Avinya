# TrustLens Dataset — RAGTruth (preprocessed)

**This is the dataset. Downloaded, verified, normalised, split, and ready to load.**

Everything below was produced by running `prepare_ragtruth.py` against a fresh clone of the official repo, not copied from documentation. All counts are measured from the actual files.

---

## Source & licence

| | |
|---|---|
| Dataset | **RAGTruth** — Niu et al., ACL 2024 |
| Origin | `https://github.com/ParticleMedia/RAGTruth` |
| Licence | **MIT** (full text in `LICENSE_RAGTruth_MIT.txt`) — commercial use permitted |
| Why this one | The only large public corpus with **human-annotated hallucination spans**. Your product output is span-level; so is this dataset. |

**Cite it:**
> Niu et al. *RAGTruth: A Hallucination Corpus for Developing Trustworthy Retrieval-Augmented Language Models.* ACL 2024.

---

## Files

| File | Rows | Size | Use it for |
|---|---|---|---|
| `data/eval_slice.jsonl` | **100** | 360 KB | **FLOW-15 benchmarking.** Balanced 50/50. Start here. |
| `data/dev_slice.jsonl` | 10 | 29 KB | **Iterate on this during the build.** Never tune on eval_slice. |
| `data/demo_cases.json` | 3 | 9 KB | **FLOW-16 demo.** One clean, one evident hallucination, one subtle. |
| `data/ragtruth_test.jsonl` | 2,675 | 9.2 MB | Full test split |
| `data/ragtruth_test.jsonl.gz` | 2,675 | 1.0 MB | Same, compressed |
| `data/ragtruth_train.jsonl.gz` | 14,942 | 5.8 MB | Only if you fine-tune (FLOW-01 advises against it) |
| `data/stats.json` | — | — | Measured counts |
| `prepare_ragtruth.py` | — | — | Regenerate everything from the raw repo |

---

## Measured statistics

```
total rows        17,617   (173 dropped: quality != "good")
train             14,942   hallucinated 6,698  (44.8%)
test               2,675   hallucinated   943  (35.3%)
total spans       14,226
offset mismatches      0   ← every span verified against its answer string
```

**By task:** Data2txt 6,195 · QA 5,767 · Summary 5,655
**By model:** ~2,950 each from gpt-4-0613, gpt-3.5-turbo-0613, mistral-7B-instruct, llama-2-7b/13b/70b-chat

**Span label types:**

| Label | Count | Meaning |
|---|---|---|
| Evident Baseless Info | 6,205 | Obviously fabricated — not in the source at all |
| Evident Conflict | 5,306 | Obviously contradicts the source |
| Subtle Baseless Info | 2,514 | Quietly unsupported |
| **Subtle Conflict** | **201** | Quietly contradicts — **the hardest class** |

Those 201 subtle conflicts are where a demo gets interesting. Finding one on stage is a stronger moment than catching an obvious fabrication.

---

## Schema (one flat object per row)

```json
{
  "id": "response id",
  "split": "train | test",
  "task_type": "QA | Summary | Data2txt",
  "model": "gpt-4-0613 | llama-2-7b-chat | ...",
  "question": "normalised — always a usable question string",
  "context": "normalised — always a plain string, whatever the task type",
  "answer": "the model's generated response",
  "spans": [
    {
      "start": 636,
      "end": 653,
      "text": "February 7, 2022.",
      "label_type": "Evident Conflict",
      "severity": "evident | subtle",
      "kind": "conflict | baseless_info",
      "meta": "Original: February 7 (1945) / Generated: February 7, 2022"
    }
  ],
  "has_hallucination": true,
  "n_spans": 1
}
```

**Guaranteed invariant:** `answer[start:end] == text` for every span in every row. Independently re-asserted after writing. This is contract C2 from `workflow/_shared/CONTRACTS.md`, so the data drops straight into FLOW-07 and FLOW-15 without adaptation.

---

## What preprocessing actually did

The raw repo is two files that need joining, and `source_info` has **three different shapes** depending on task type. That inconsistency is the one real trap in this dataset, and it is now resolved:

| Task | Raw `source_info` | Normalised to |
|---|---|---|
| QA | `dict{question, passages}` | `question` + `context` = passages |
| Summary | `str` | question = "Summarise the following document." · context = the document |
| Data2txt | `dict` of business fields (nested hours, attributes) | question = "Write an overview of this business." · context = flattened `key: value` lines |

Also done: joined `response.jsonl` ↔ `source_info.jsonl` on `source_id`; dropped 173 rows where `quality != "good"` (144 `incorrect_refusal`, 29 `truncated` — degenerate generations that would corrupt your metrics); validated every span offset; derived `severity` and `kind` from `label_type`; built a balanced eval slice with `seed=42`.

---

## Load it

```python
import json

rows = [json.loads(l) for l in open("data/eval_slice.jsonl", encoding="utf-8")]

r = rows[0]
print(r["question"])
print(r["context"][:200])
print(r["answer"])
for s in r["spans"]:
    print(f"  HALLUCINATION [{s['severity']}/{s['kind']}]: {s['text']!r}")
```

Straight into the FLOW-07 verdict engine:

```python
from lettucedetect.models.inference import HallucinationDetector
det = HallucinationDetector(method="transformer",
        model_path="KRLabsOrg/lettucedect-base-modernbert-en-v1")

pred = det.predict(context=[r["context"]], question=r["question"],
                   answer=r["answer"], output_format="spans")
print("predicted:", pred)
print("gold:     ", r["spans"])
```

Compressed splits:
```python
import gzip, json
rows = [json.loads(l) for l in gzip.open("data/ragtruth_test.jsonl.gz", "rt", encoding="utf-8")]
```

Regenerate from scratch:
```bash
git clone --depth 1 https://github.com/ParticleMedia/RAGTruth.git
python prepare_ragtruth.py --raw RAGTruth/dataset --out data/processed
```

---

## Two things you must say when you report numbers

**1. `eval_slice.jsonl` is re-balanced to 50/50.** The natural test-split rate is 35.3%. Balancing makes accuracy interpretable (random = 50%) but **changes the base rate**, so precision will not match production. Report **balanced accuracy** and state the slice composition. Reporting raw accuracy on a re-balanced set without saying so is the kind of thing a sharp judge catches.

**2. LettuceDetect was trained on RAGTruth's train split.** Evaluate on **test only**. This is a genuine advantage — it makes your numbers directly comparable to LettuceDetect's published 79.22% example-level F1 on this exact benchmark, and a judge can verify the claim. But if you accidentally evaluate on train and score 95%, that is leakage, not performance. **A suspiciously good score deserves more scrutiny than a bad one.**

---

## Honest limitations

- **Grounded, not open-world.** RAGTruth measures faithfulness to a provided context. It cannot evaluate your open-web mode (FLOW-06). Nothing public does that well at span level.
- **Generated in 2023.** Models are gpt-4-0613, gpt-3.5-turbo-0613, llama-2, mistral-7B. Current models hallucinate less and differently, so absolute rates here are higher than you would see today.
- **Three task types only.** No medical, legal, or financial content — so it cannot validate your risk-routing tiers (FLOW-10). Demo those; don't claim benchmark support for them.
- **Human annotation has noise.** Subtle Conflict has only 201 examples, so per-class metrics on it will be unstable.
- **English only.** For multilingual, `utahnlp/x-fact` (MIT, 25 languages incl. Hindi, Tamil, Bengali) is the fallback — but it is claim-level, not span-level.

---

## If you also want a secondary eval set

| Dataset | ID | Licence | Caveat |
|---|---|---|---|
| HaluBench | `PatronusAI/HaluBench` | **cc-by-nc-2.0 — non-commercial** | Repackages RAGTruth → **contamination if combined with this** |
| LLM-AggreFact | `lytang/LLM-AggreFact` | gated | Needs HF login + accepting terms |
| HaluEval | `pminervini/HaluEval` | MIT | Response-level only, no spans |

**Recommendation: don't.** One well-understood dataset used correctly beats three used hastily, and you have 24 hours.
