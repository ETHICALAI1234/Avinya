# ETHICAL AI — Universal AI Trust, Verification & Human Assistance Platform

A runnable hackathon-ready full-stack reference implementation for the submitted Ethical AI problem statement:

> AI-generated answers can contain hallucinations, unsupported claims, contradictions, and unreliable sources. Users lack a reliable way to verify these claims and understand which information can be trusted.

## What is included

- Universal AI Assistant
- AI answer verification
- Claim extraction
- Evidence/source panel
- Citation integrity checks
- Contradiction and freshness checks
- Risk-adaptive autonomy
- Human availability/review workflow
- Multilingual UI (English, Telugu, Hindi)
- Browser voice input/output
- Emergency safety mode
- Alerts center
- Evidence graph
- Audit trail
- Domain modes: Citizen, Agriculture, Healthcare, Finance, Legal, Education, Government, Public Safety, Research, Enterprise
- Demo mode with deterministic mock verification, so the website works without API keys
- Optional OpenAI-compatible backend integration
- FastAPI backend + React/Vite frontend
- Docker Compose setup
- API documentation through FastAPI

## Requirements

- Node.js 20.19+ or 22.12+
- Python 3.11+
- npm
- Optional: Docker Desktop

Vite currently documents Node.js 20.19+ / 22.12+ requirements.
FastAPI can be run locally with `fastapi dev` and containerized for deployment.

## Fastest Windows setup

Open TWO terminals in VS Code.

### Terminal 1 — backend

```powershell
cd backend
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
fastapi dev app/main.py
```

Backend:
http://127.0.0.1:8000

API docs:
http://127.0.0.1:8000/docs

### Terminal 2 — frontend

```powershell
cd frontend
npm install
copy .env.example .env
npm run dev
```

Frontend:
http://localhost:5173

## Optional AI provider

The default demo is deliberately deterministic and needs no API key.

To connect an OpenAI-compatible provider, edit `backend/.env`:

```env
AI_PROVIDER=openai_compatible
AI_API_KEY=your_key
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=your_model
```

Then restart the backend.

If no key is configured, the backend automatically uses the safe demo engine.

## Docker

From the project root:

```powershell
docker compose up --build
```

Frontend:
http://localhost:5173

Backend:
http://localhost:8000

## Demo flow for judges

1. Open Dashboard.
2. Go to Verify AI.
3. Paste or use the preloaded demo answer.
4. Click Verify.
5. Open Claim Explorer.
6. Click the contradicted claim.
7. Open Evidence Graph.
8. Switch to Healthcare and ask a high-risk question.
9. Show Human Review.
10. Toggle human availability off and show Safe AI Fallback.
11. Switch language to Telugu.
12. Try Emergency Mode.
13. Open Audit Trail.

## Important product positioning

ETHICAL AI is not a replacement for ChatGPT, Claude, Gemini, or human professionals.

It is an independent trust and assistance layer:

AI generates -> ETHICAL AI verifies -> risk is assessed -> human judgment is required when appropriate.

The demo's verification results are illustrative unless connected to real evidence/search providers. Do not present mock results as real-world factual verification.

## Production next steps

- Replace demo evidence with authoritative retrieval/search connectors.
- Add PostgreSQL + pgvector.
- Add authentication/RBAC/SSO.
- Add encrypted organization knowledge bases.
- Add real human-review notifications.
- Add source-specific policies and allowlists.
- Add observability, rate limits, secrets management, backups and audit retention.
- Add evaluation datasets and measured benchmarks.
