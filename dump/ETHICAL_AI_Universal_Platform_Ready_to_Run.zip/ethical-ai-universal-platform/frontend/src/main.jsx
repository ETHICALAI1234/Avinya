import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity, AlertTriangle, ArrowRight, Bot, CheckCircle2, ChevronRight, CircleDot,
  ClipboardCheck, Clock3, FileCheck2, GitBranch, Globe2, Headphones, HeartPulse,
  History, Languages, LayoutDashboard, Menu, Mic, Network, PlayCircle, Radio,
  Search, Send, Shield, ShieldCheck, Siren, Sparkles, Stethoscope, Users, Volume2,
  XCircle, Zap
} from 'lucide-react';
import './styles.css';

const API = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

const domains = [
  ['dashboard','Command Center',LayoutDashboard],
  ['assistant','AI Assistant',Bot],
  ['verify','Verify AI',ShieldCheck],
  ['claims','Claim Explorer',ClipboardCheck],
  ['evidence','Evidence Center',FileCheck2],
  ['graph','Evidence Graph',Network],
  ['risk','Risk & Human Control',Shield],
  ['reviews','Human Review',Users],
  ['domains','Universal Domains',Globe2],
  ['voice','Voice & Languages',Mic],
  ['emergency','Emergency Center',Siren],
  ['alerts','Alerts Center',Radio],
  ['audit','Audit Trail',History],
];

const domainOptions = [
  ['citizen','Citizen'],['agriculture','Agriculture'],['healthcare','Healthcare'],['finance','Finance'],
  ['legal','Legal'],['education','Education'],['government','Government'],['public_safety','Public Safety'],
  ['research','Research'],['enterprise','Enterprise']
];

const translations = {
  en: { ask:'Ask ETHICAL AI anything...', send:'Send', verify:'Verify Answer', assistant:'AI Assistant', human:'Human available', fallback:'Safe AI fallback', verified:'Verified', unsupported:'Unsupported', partial:'Partial', contradicted:'Contradicted' },
  te: { ask:'ETHICAL AI ని ఏదైనా అడగండి...', send:'పంపు', verify:'సమాధానాన్ని తనిఖీ చేయి', assistant:'AI సహాయకుడు', human:'మానవ నిపుణుడు అందుబాటులో', fallback:'సురక్షిత AI ప్రత్యామ్నాయం', verified:'ధృవీకరించబడింది', unsupported:'మద్దతు లేదు', partial:'పాక్షికం', contradicted:'విరుద్ధం' },
  hi: { ask:'ETHICAL AI से कुछ भी पूछें...', send:'भेजें', verify:'उत्तर सत्यापित करें', assistant:'AI सहायक', human:'मानव विशेषज्ञ उपलब्ध', fallback:'सुरक्षित AI विकल्प', verified:'समर्थित', unsupported:'असमर्थित', partial:'आंशिक', contradicted:'विरोधाभासी' }
};

function App() {
  const [page,setPage] = useState('dashboard');
  const [language,setLanguage] = useState('en');
  const [domain,setDomain] = useState('citizen');
  const [humanAvailable,setHumanAvailable] = useState(true);
  const [question,setQuestion] = useState('');
  const [answer,setAnswer] = useState('');
  const [analysis,setAnalysis] = useState(null);
  const [loading,setLoading] = useState(false);
  const [alerts,setAlerts] = useState([]);
  const [reviews,setReviews] = useState([]);
  const [audit,setAudit] = useState([]);
  const [voice,setVoice] = useState(false);
  const recognitionRef = useRef(null);
  const t = translations[language];

  useEffect(() => {
    fetch(`${API}/api/alerts`).then(r=>r.json()).then(setAlerts).catch(()=>{});
    fetch(`${API}/api/reviews`).then(r=>r.json()).then(setReviews).catch(()=>{});
    fetch(`${API}/api/audit`).then(r=>r.json()).then(setAudit).catch(()=>{});
  }, [analysis]);

  const analyze = async (text=question, suppliedAnswer=answer) => {
    if (!text.trim() && !suppliedAnswer.trim()) return;
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/analyze`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({question:text || 'Verify this answer', answer:suppliedAnswer || null, domain, language, human_available:humanAvailable})
      });
      const data = await r.json();
      setAnalysis(data);
      setAnswer(data.answer);
      setPage('claims');
    } catch(e) {
      setAnswer('Backend is not running. Start FastAPI from the backend folder.');
    } finally { setLoading(false); }
  };

  const chat = async () => {
    if (!question.trim()) return;
    setLoading(true);
    try {
      const r = await fetch(`${API}/api/chat`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({question,domain,language,human_available:humanAvailable})
      });
      const data = await r.json();
      setAnswer(data.answer);
      if (data.human_required) setPage('risk');
    } catch(e) {
      setAnswer('Backend is not running. Start FastAPI from the backend folder.');
    } finally { setLoading(false); }
  };

  const startVoice = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert('Speech recognition is not supported in this browser.'); return; }
    const rec = new SR();
    rec.lang = language==='te'?'te-IN':language==='hi'?'hi-IN':'en-IN';
    rec.onstart = ()=>setVoice(true);
    rec.onend = ()=>setVoice(false);
    rec.onresult = (e)=>setQuestion(e.results[0][0].transcript);
    recognitionRef.current = rec;
    rec.start();
  };

  const speak = () => {
    if (!answer || !window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(answer);
    u.lang = language==='te'?'te-IN':language==='hi'?'hi-IN':'en-IN';
    window.speechSynthesis.speak(u);
  };

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><ShieldCheck size={24}/></div>
          <div><strong>ETHICAL AI</strong><span>Trust Layer</span></div>
        </div>
        <div className="side-label">PLATFORM</div>
        <nav>
          {domains.map(([id,label,Icon]) => (
            <button key={id} className={page===id?'nav active':'nav'} onClick={()=>setPage(id)}>
              <Icon size={18}/><span>{label}</span>
              {['verify','risk','reviews'].includes(id) && <span className="nav-dot"/>}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="human-card">
            <div className="human-top"><CircleDot size={14}/><b>Human Control</b></div>
            <p>AI autonomy is adaptive to risk.</p>
            <button className={humanAvailable?'toggle on':'toggle'} onClick={()=>setHumanAvailable(!humanAvailable)}>
              <span></span>{humanAvailable?'Available':'Unavailable'}
            </button>
          </div>
          <div className="safe-note"><Shield size={14}/> Evidence before confidence.</div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="mobile-title"><Menu size={20}/><b>ETHICAL AI</b></div>
          <div className="breadcrumbs">Universal Trust Platform <ChevronRight size={14}/> {domains.find(x=>x[0]===page)?.[1] || 'Command Center'}</div>
          <div className="top-actions">
            <select value={language} onChange={e=>setLanguage(e.target.value)}><option value="en">English</option><option value="te">తెలుగు</option><option value="hi">हिन्दी</option></select>
            <select value={domain} onChange={e=>setDomain(e.target.value)}>{domainOptions.map(x=><option key={x[0]} value={x[0]}>{x[1]}</option>)}</select>
            <div className="status-pill"><span></span>System healthy</div>
          </div>
        </header>

        <div className="content">
          {page==='dashboard' && <Dashboard setPage={setPage} analysis={analysis} alerts={alerts}/>}
          {page==='assistant' && <Assistant question={question} setQuestion={setQuestion} answer={answer} loading={loading} chat={chat} analyze={analyze} startVoice={startVoice} voice={voice} speak={speak} t={t} domain={domain}/>}
          {page==='verify' && <Verify answer={answer} setAnswer={setAnswer} question={question} setQuestion={setQuestion} analyze={analyze} loading={loading} t={t}/>}
          {page==='claims' && <Claims analysis={analysis} setPage={setPage} t={t}/>}
          {page==='evidence' && <Evidence analysis={analysis}/>}
          {page==='graph' && <Graph analysis={analysis}/>}
          {page==='risk' && <Risk analysis={analysis} humanAvailable={humanAvailable} setHumanAvailable={setHumanAvailable} setPage={setPage}/>}
          {page==='reviews' && <Reviews reviews={reviews} analysis={analysis} setPage={setPage}/>}
          {page==='domains' && <Domains setDomain={setDomain} setPage={setPage}/>}
          {page==='voice' && <VoicePage language={language} setLanguage={setLanguage} startVoice={startVoice} voice={voice} speak={speak} question={question} setQuestion={setQuestion} answer={answer}/>}
          {page==='emergency' && <Emergency/>}
          {page==='alerts' && <Alerts alerts={alerts}/>}
          {page==='audit' && <Audit audit={audit}/>}
        </div>
      </main>
    </div>
  )
}

function PageTitle({eyebrow,title,desc,action}) {
  return <div className="page-title"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{desc}</p></div>{action}</div>
}

function Dashboard({setPage,analysis,alerts}) {
  const stats=[['12,480','AI interactions','up'],['58,721','Claims analyzed','up'],['1,284','Needs verification','warn'],['217','Human escalations','critical']];
  return <div>
    <PageTitle eyebrow="COMMAND CENTER" title="Universal AI Trust" desc="One platform to assist, verify, assess risk and keep humans in control." action={<button className="primary" onClick={()=>setPage('assistant')}><Sparkles size={16}/> Start AI session</button>}/>
    <div className="hero-card">
      <div className="hero-copy"><div className="live-tag"><span/> TRUST ENGINE ONLINE</div><h2>Verify AI before you trust AI.</h2><p>ETHICAL AI sits between AI output and human action. It extracts claims, evaluates evidence, detects contradictions, assesses risk and escalates when human judgment is required.</p><div className="hero-actions"><button className="primary" onClick={()=>setPage('verify')}>Verify an AI answer <ArrowRight size={16}/></button><button className="secondary" onClick={()=>setPage('graph')}><Network size={16}/> Explore evidence graph</button></div></div>
      <div className="hero-orbit"><div className="orbit-ring r1"/><div className="orbit-ring r2"/><div className="orbit-core"><ShieldCheck size={42}/><span>TRUST</span></div><div className="orbit-node n1">Evidence</div><div className="orbit-node n2">Risk</div><div className="orbit-node n3">Human</div></div>
    </div>
    <div className="stat-grid">{stats.map(s=><div className="stat-card" key={s[1]}><div className="stat-value">{s[0]}</div><div className="stat-label">{s[1]}</div><div className={`stat-trend ${s[2]}`}>{s[2]==='up'?'Live':'Attention'}</div></div>)}</div>
    <div className="grid-2">
      <section className="panel"><div className="panel-head"><div><span className="eyebrow">LIVE WORKFLOW</span><h3>Risk-adaptive autonomy</h3></div><Activity size={20}/></div><div className="risk-flow">{[['LOW','AI can assist','safe'],['MEDIUM','Stronger evidence','mid'],['HIGH','Human review','high'],['CRITICAL','Human / emergency','critical']].map(x=><div className="flow-row" key={x[0]}><span className={`risk-badge ${x[2]}`}>{x[0]}</span><span>{x[1]}</span><ChevronRight size={15}/></div>)}</div></section>
      <section className="panel"><div className="panel-head"><div><span className="eyebrow">RECENT</span><h3>Trust activity</h3></div><button className="link" onClick={()=>setPage('audit')}>View audit</button></div><div className="activity-list"><ActivityItem icon={<CheckCircle2/>} title="Claim verification completed" meta="12 claims • strong evidence"/><ActivityItem icon={<AlertTriangle/>} title="Human review triggered" meta="High-risk request"/><ActivityItem icon={<GitBranch/>} title="Contradiction detected" meta="Temporal source conflict"/></div></section>
    </div>
    <section className="panel alert-strip"><div><span className="eyebrow">ACTIVE ALERTS</span><h3>{alerts.length} governance alerts</h3><p>Verified-source alerting and human approval controls are enabled.</p></div><button className="secondary" onClick={()=>setPage('alerts')}>Open alerts</button></section>
  </div>
}

function ActivityItem({icon,title,meta}) { return <div className="activity-item"><div className="activity-icon">{icon}</div><div><b>{title}</b><span>{meta}</span></div><ChevronRight size={16}/></div> }

function Assistant({question,setQuestion,answer,loading,chat,analyze,startVoice,voice,speak,t,domain}) {
  return <div><PageTitle eyebrow="AI ASSISTANT" title={t.assistant} desc="Text or voice assistance with risk-aware human oversight."/>
    <div className="assistant-layout">
      <section className="chat-card">
        <div className="chat-head"><div className="avatar"><Bot/></div><div><b>ETHICAL AI Assistant</b><span>Evidence-first • {domain}</span></div><div className="online"><span/> Online</div></div>
        <div className="chat-body">
          <div className="message bot"><div className="msg-avatar"><ShieldCheck/></div><div><b>ETHICAL AI</b><p>Ask me a question. I can assist, then you can verify the answer claim by claim. High-risk topics may require human judgment.</p></div></div>
          {answer && <div className="message bot"><div className="msg-avatar"><ShieldCheck/></div><div><b>ETHICAL AI</b><p>{answer}</p><div className="msg-actions"><button onClick={()=>analyze(question,answer)}><ShieldCheck size={14}/> {t.verify}</button><button onClick={speak}><Volume2 size={14}/> Speak</button></div></div></div>}
        </div>
        <div className="composer"><textarea value={question} onChange={e=>setQuestion(e.target.value)} placeholder={t.ask} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();chat()}}}/><div className="compose-tools"><button onClick={startVoice} className={voice?'recording':''}><Mic size={18}/>{voice?'Listening':'Voice'}</button><span>Enter to send</span><button className="send" onClick={chat} disabled={loading}>{loading?<span className="spinner"/>:<Send size={17}/>} {t.send}</button></div></div>
      </section>
      <aside className="side-panel"><div className="mini-card"><div className="mini-icon"><ShieldCheck/></div><b>Trust by design</b><p>AI output is treated as untrusted until claims have evidence.</p></div><div className="mini-card"><div className="mini-icon"><Users/></div><b>Human control</b><p>High-risk requests can be escalated to an authorized reviewer.</p></div><div className="mini-card"><div className="mini-icon"><Languages/></div><b>Multilingual</b><p>Ask in English, Telugu or Hindi in this demo.</p></div></aside>
    </div>
  </div>
}

function Verify({answer,setAnswer,question,setQuestion,analyze,loading,t}) {
  const sample=`Scheme X was launched in 2024. Farmers receive ₹10,000. Applications are available online.`;
  return <div><PageTitle eyebrow="VERIFY AI" title="Independent answer verification" desc="Paste any AI output and inspect the claim-level evidence chain." action={<button className="secondary" onClick={()=>{setAnswer(sample);setQuestion('Verify this AI answer')}}><PlayCircle size={16}/> Load demo</button>}/>
    <div className="verify-box"><div className="input-label">AI-GENERATED ANSWER</div><textarea value={answer} onChange={e=>setAnswer(e.target.value)} placeholder="Paste an answer from ChatGPT, Claude, Gemini or another model..."/><div className="verify-bottom"><div className="hint"><Shield size={15}/> Your AI provider is not changed. ETHICAL AI verifies the output.</div><button className="primary" onClick={()=>analyze(question||'Verify this answer',answer)} disabled={loading}>{loading?<span className="spinner"/>:<ShieldCheck size={17}/>} {t.verify}</button></div></div>
    <div className="principles"><Principle title="Claim-level" text="Break an answer into atomic claims."/><Principle title="Evidence-first" text="Inspect source quality and support."/><Principle title="Risk-adaptive" text="Escalate when AI should not act alone."/><Principle title="Auditable" text="Keep a trace of what happened."/></div>
  </div>
}
function Principle({title,text}) { return <div><b>{title}</b><span>{text}</span></div> }

function Claims({analysis,setPage,t}) {
  if(!analysis) return <Empty title="No analysis yet" text="Open Verify AI, load the demo answer, and run verification." go={()=>setPage('verify')}/>;
  return <div><PageTitle eyebrow="CLAIM EXPLORER" title="What exactly is supported?" desc={`${analysis.claims.length} claims extracted • ${analysis.verification_strength} evidence strength`} action={<span className={`risk-badge ${analysis.risk}`}>{analysis.risk.toUpperCase()} RISK</span>}/>
    <div className="summary-row">{[['supported','Supported'],['partial','Partially supported'],['contradicted','Contradicted'],['unverifiable','Unverifiable']].map(([k,l])=><div className="summary-chip" key={k}><b>{analysis.status_counts[k]||0}</b><span>{l}</span></div>)}</div>
    <div className="claims-list">{analysis.claims.map((c,i)=><div className="claim-card" key={c.id}><div className="claim-num">0{i+1}</div><div className="claim-main"><div className="claim-status"><Status status={c.status}/><span>{c.strength} evidence</span></div><h3>{c.text}</h3><p>{c.reason}</p><div className="claim-foot"><span>{c.source_ids.length} evidence source(s)</span><button className="link" onClick={()=>setPage('evidence')}>Inspect evidence <ArrowRight size={14}/></button></div></div></div>)}</div>
  </div>
}
function Status({status}) { const map={supported:[CheckCircle2,'Supported'],partial:[AlertTriangle,'Partially supported'],contradicted:[XCircle,'Contradicted'],unverifiable:[CircleDot,'Unverifiable']}; const [I,l]=map[status]||map.unverifiable; return <span className={`status ${status}`}><I size={15}/>{l}</span> }

function Evidence({analysis}) {
  if(!analysis) return <Empty title="No evidence yet" text="Run an analysis first." />;
  return <div><PageTitle eyebrow="EVIDENCE CENTER" title="Evidence & source intelligence" desc="Inspect the evidence attached to each claim and its quality signals."/>
    <div className="evidence-grid">{analysis.evidence.map((e,i)=><div className="evidence-card" key={i}><div className="evidence-top"><span className={`source-type ${e.source.type==='Demo document'?'demo':''}`}>{e.source.type}</span><Status status={e.support}/></div><h3>{e.source.name}</h3><p>{e.passage}</p><div className="source-meta"><span>Authority <b>{e.source.authority}</b></span><span>Freshness <b>{e.source.freshness}</b></span><span>Independence <b>{e.source.independence}</b></span></div><div className="source-url">{e.source.url}</div></div>)}</div>
  </div>
}

function Graph({analysis}) {
  const claims=analysis?.claims||[{id:'CLM-001',text:'Claims require evidence',status:'supported'},{id:'CLM-002',text:'Citations must support claims',status:'supported'},{id:'CLM-003',text:'High-risk needs human oversight',status:'supported'},{id:'CLM-004',text:'Policy may be outdated',status:'partial'},{id:'CLM-005',text:'AI can guarantee correctness',status:'contradicted'}];
  return <div><PageTitle eyebrow="EVIDENCE GRAPH" title="See the evidence chain" desc="A visual map from AI answer → claim → source → verification status."/>
    <div className="graph-card"><div className="graph-canvas"><div className="graph-node answer-node"><ShieldCheck/><b>AI ANSWER</b><span>Untrusted input</span></div><div className="graph-lines">{claims.map((c,i)=><div className="graph-branch" key={c.id}><div className="line"/><div className={`graph-node claim-node ${c.status}`}><span>CLAIM {i+1}</span><b>{c.text}</b><Status status={c.status}/></div><div className="line small"/><div className="graph-node source-node"><FileCheck2/><span>{c.source_ids?.[0]||'SOURCE'}</span></div></div>)}</div></div></div>
  </div>
}

function Risk({analysis,humanAvailable,setHumanAvailable,setPage}) {
  const risk=analysis?.risk||'high'; const required=analysis?.human_required ?? true;
  return <div><PageTitle eyebrow="RISK & HUMAN CONTROL" title="AI autonomy is risk-adaptive" desc="The system decides when AI can assist and when human judgment is required."/>
    <div className="risk-hero"><div><div className={`big-risk ${risk}`}>{risk.toUpperCase()}</div><h2>{required?'Human judgment is required':'AI can assist with current evidence'}</h2><p>{analysis?`Analysis ${analysis.id.slice(0,8)}… • ${analysis.domain}`:'Use Verify AI to generate a live assessment.'}</p></div><div className="human-switch"><span>Human available</span><button className={humanAvailable?'toggle on':'toggle'} onClick={()=>setHumanAvailable(!humanAvailable)}><span/>{humanAvailable?'YES':'NO'}</button></div></div>
    <div className="autonomy-grid">{[['LOW','AI can answer','Low-risk informational tasks'],['MEDIUM','Stronger evidence','Uncertainty should be visible'],['HIGH','Human review','Professional/organizational judgment'],['CRITICAL','Human / emergency','Safety-critical situations']].map(x=><div className={`auto-card ${x[0].toLowerCase()} ${risk===x[0].toLowerCase()?'selected':''}`} key={x[0]}><b>{x[0]}</b><h3>{x[1]}</h3><p>{x[2]}</p></div>)}</div>
    <div className="fallback-card"><div><Shield/><b>{humanAvailable?'Human review path active':'Safe AI fallback active'}</b><p>{humanAvailable?'A reviewer can inspect the evidence and make the final decision.':'AI remains bounded and explicitly states that professional judgment is unavailable.'}</p></div><button className="secondary" onClick={()=>setPage('reviews')}>Open human queue <ArrowRight size={16}/></button></div>
  </div>
}

function Reviews({reviews,analysis,setPage}) {
  return <div><PageTitle eyebrow="HUMAN REVIEW" title="Human-in-the-loop control" desc="High-risk requests are routed to authorized people instead of silently delegating decisions to AI."/>
    <div className="review-grid"><div className="review-summary"><div className="review-number">{reviews.length}</div><span>Pending / recorded reviews</span><div className="review-line"><span/> Human availability: {analysis?.human_available?'ON':'configurable'}</div></div><div className="panel"><div className="panel-head"><div><span className="eyebrow">QUEUE</span><h3>Review requests</h3></div></div>{reviews.length?reviews.map(r=><div className="review-row" key={r.id}><div className={`risk-badge ${r.risk}`}>{r.risk}</div><div><b>{r.domain}</b><span>{r.note}</span></div><button className="secondary">Open</button></div>):<div className="empty-small">No review requests yet. Run a high-risk analysis.</div>}</div></div>
  </div>
}

function Domains({setDomain,setPage}) {
  const descriptions={citizen:'Public information and claim verification.',agriculture:'Evidence-backed agricultural assistance.',healthcare:'Strict high-risk clinical information guardrails.',finance:'Financial policy and regulatory verification.',legal:'Legal information with human-review guardrails.',education:'Learning, teaching and citation verification.',government:'Official-source and policy verification.',public_safety:'Safety procedures and critical escalation.',research:'Research claim and citation assurance.',enterprise:'Internal AI assurance and governance.'};
  return <div><PageTitle eyebrow="UNIVERSAL DOMAINS" title="One trust engine, many sectors" desc="Domain policies change the evidence, risk and human-control rules without rebuilding the platform."/>
    <div className="domain-grid">{domainOptions.map(([id,name])=><div className="domain-card" key={id}><div className="domain-icon">{id==='healthcare'?<HeartPulse/>:id==='agriculture'?<Zap/>:<Globe2/>}</div><b>{name}</b><p>{descriptions[id]}</p><button className="link" onClick={()=>{setDomain(id);setPage('assistant')}}>Use this mode <ArrowRight size={14}/></button></div>)}</div>
  </div>
}

function VoicePage({language,setLanguage,startVoice,voice,question,setQuestion,answer,speak}) {
  return <div><PageTitle eyebrow="VOICE & LANGUAGES" title="Speak naturally" desc="Browser voice input/output with multilingual controls."/>
    <div className="voice-hero"><div className={`mic-orb ${voice?'recording':''}`} onClick={startVoice}><Mic size={48}/></div><h2>{voice?'Listening…':'Tap to speak'}</h2><p>Language</p><div className="lang-pills">{[['en','English'],['te','తెలుగు'],['hi','हिन्दी']].map(x=><button className={language===x[0]?'selected':''} onClick={()=>setLanguage(x[0])} key={x[0]}>{x[1]}</button>)}</div><textarea value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Recognized speech appears here…"/><button className="secondary" onClick={speak}><Volume2 size={16}/> Speak latest answer</button></div>
  </div>
}

function Emergency() {
  return <div><PageTitle eyebrow="EMERGENCY CENTER" title="Safety-first escalation" desc="AI provides bounded support; verified emergency contacts and human services remain authoritative."/>
    <div className="emergency-banner"><Siren size={28}/><div><b>CRITICAL MODE</b><p>If someone is in immediate danger, contact the appropriate emergency service. Do not rely on an AI system as an emergency responder.</p></div></div>
    <div className="emergency-grid">{[['112','Emergency services','All-in-one emergency response'],['100','Police','Public safety assistance'],['108','Ambulance','Medical emergency response'],['101','Fire','Fire and rescue']].map(x=><div className="emergency-card" key={x[0]}><div className="em-number">{x[0]}</div><b>{x[1]}</b><p>{x[2]}</p><button className="primary" onClick={()=>alert(`Configure this verified emergency contact before production: ${x[0]}`)}>Call / configure</button></div>)}</div>
    <div className="safety-box"><ShieldCheck/><div><b>Deployment requirement</b><p>Emergency directories must be verified for the deployment geography and maintained by an authorized administrator. The LLM must never invent emergency numbers.</p></div></div>
  </div>
}

function Alerts({alerts}) {
  return <div><PageTitle eyebrow="ALERTS CENTER" title="Verified-source alerts" desc="Operational alerts should originate from authorized sources and pass verification, freshness and approval checks."/>
    <div className="alerts-list">{alerts.map(a=><div className="alert-card" key={a.id}><div className={`alert-icon ${a.severity}`}><AlertTriangle/></div><div><div className="alert-meta">{a.category} • {a.time}</div><h3>{a.title}</h3><p>{a.body}</p></div><span className={`risk-badge ${a.severity}`}>{a.severity}</span></div>)}</div>
  </div>
}

function Audit({audit}) {
  return <div><PageTitle eyebrow="AUDIT TRAIL" title="Trace every important decision" desc="Record what the AI said, what evidence was used, what risk was assigned and whether a human was involved."/>
    <div className="audit-table"><div className="audit-head"><span>Event</span><span>Time</span><span>Metadata</span></div>{audit.length?audit.map(a=><div className="audit-row" key={a.id}><b>{a.event}</b><span>{new Date(a.timestamp).toLocaleString()}</span><code>{JSON.stringify(a.metadata)}</code></div>):<div className="empty-small">No events yet. Run an analysis.</div>}</div>
  </div>
}

function Empty({title,text,go}) { return <div className="empty"><div className="empty-icon"><Search/></div><h2>{title}</h2><p>{text}</p>{go&&<button className="primary" onClick={go}>Go there <ArrowRight size={16}/></button>}</div> }

createRoot(document.getElementById('root')).render(<App/>);
