from __future__ import annotations

import os
import re
import uuid
from datetime import datetime, timezone
from typing import Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()

app = FastAPI(
    title="ETHICAL AI Universal Trust Platform API",
    version="1.0.0",
    description="AI trust, verification, risk and human-assistance API."
)

origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins + ["http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ANALYSES: dict[str, dict[str, Any]] = {}
REVIEWS: list[dict[str, Any]] = []
AUDIT: list[dict[str, Any]] = []

DOMAINS = [
    {"id": "citizen", "name": "Citizen", "risk": "medium"},
    {"id": "agriculture", "name": "Agriculture", "risk": "medium"},
    {"id": "healthcare", "name": "Healthcare", "risk": "high"},
    {"id": "finance", "name": "Finance", "risk": "high"},
    {"id": "legal", "name": "Legal", "risk": "high"},
    {"id": "education", "name": "Education", "risk": "medium"},
    {"id": "government", "name": "Government", "risk": "high"},
    {"id": "public_safety", "name": "Public Safety", "risk": "critical"},
    {"id": "research", "name": "Research", "risk": "medium"},
    {"id": "enterprise", "name": "Enterprise", "risk": "high"},
]

EMERGENCY_SERVICES = [
    {"name": "Emergency services", "number": "112", "verified_label": "Configure/verify for deployment"},
    {"name": "Police", "number": "100", "verified_label": "Configure/verify for deployment"},
    {"name": "Ambulance", "number": "108", "verified_label": "Configure/verify for deployment"},
    {"name": "Fire", "number": "101", "verified_label": "Configure/verify for deployment"},
]

ALERTS = [
    {"id": "A-001", "title": "Verification-first alerting enabled", "category": "Platform", "severity": "info",
     "body": "Only authorized and verified sources should publish operational alerts.", "time": "Today"},
    {"id": "A-002", "title": "Human review queue", "category": "Governance", "severity": "warning",
     "body": "High-risk requests should be reviewed by an authorized person.", "time": "Today"},
    {"id": "A-003", "title": "Demo mode", "category": "System", "severity": "info",
     "body": "The local package uses illustrative evidence unless real connectors are configured.", "time": "Today"},
]

def now() -> str:
    return datetime.now(timezone.utc).isoformat()

def log(event: str, metadata: dict[str, Any] | None = None):
    AUDIT.append({"id": str(uuid.uuid4()), "event": event, "timestamp": now(), "metadata": metadata or {}})

def risk_for(question: str, domain: str) -> str:
    q = question.lower()
    critical_words = ["unconscious", "bleeding", "suicide", "emergency", "fire", "attack", "life threatening"]
    high_words = ["medicine", "medication", "diagnose", "loan", "investment", "legal", "police", "criminal", "treatment", "stop taking"]
    if any(w in q for w in critical_words) or domain == "public_safety":
        return "critical"
    if domain in {"healthcare", "finance", "legal", "government", "enterprise"} or any(w in q for w in high_words):
        return "high"
    if domain in {"agriculture", "education", "research", "citizen"}:
        return "medium"
    return "low"

def demo_answer(question: str, domain: str, language: str) -> str:
    if language == "te":
        return (
            "ఇది ETHICAL AI డెమో సమాధానం. AI సమాధానాన్ని నమ్మే ముందు దాని ముఖ్యమైన క్లెయిమ్‌లను "
            "సాక్ష్యాలు, మూలాల నాణ్యత, తాజాదనం మరియు ప్రమాద స్థాయితో తనిఖీ చేయాలి."
        )
    if language == "hi":
        return (
            "यह ETHICAL AI डेमो उत्तर है। AI उत्तर पर भरोसा करने से पहले महत्वपूर्ण दावों को "
            "साक्ष्य, स्रोत की गुणवत्ता, नवीनता और जोखिम के आधार पर सत्यापित करना चाहिए।"
        )
    if domain == "healthcare":
        return "This is an informational AI response. Treatment or medication decisions require qualified human clinical judgment."
    return (
        f"For the question “{question}”, ETHICAL AI provides an illustrative answer in demo mode. "
        "Important claims should be independently checked against authoritative, current evidence before action."
    )

def extract_claims(answer: str, domain: str) -> list[dict[str, Any]]:
    # Deterministic demo claims make the full UI testable without an API key.
    base = [
        {
            "id": "CLM-001",
            "text": "Important AI-generated claims should be checked against authoritative evidence.",
            "status": "supported",
            "strength": "high",
            "source_ids": ["SRC-001"],
            "reason": "The platform design requires evidence before trust."
        },
        {
            "id": "CLM-002",
            "text": "A citation should actually support the claim it is attached to.",
            "status": "supported",
            "strength": "high",
            "source_ids": ["SRC-002"],
            "reason": "Citation integrity checks test existence, relevance and support."
        },
        {
            "id": "CLM-003",
            "text": "High-risk decisions should not be delegated to AI alone.",
            "status": "supported",
            "strength": "high",
            "source_ids": ["SRC-003"],
            "reason": "Risk-adaptive autonomy routes high-risk cases to human oversight."
        },
        {
            "id": "CLM-004",
            "text": "A current source can supersede an older policy version.",
            "status": "partial",
            "strength": "medium",
            "source_ids": ["SRC-004", "SRC-005"],
            "reason": "Temporal reasoning requires checking effective dates and jurisdiction."
        },
        {
            "id": "CLM-005",
            "text": "AI can safely guarantee that every answer is correct.",
            "status": "contradicted",
            "strength": "high",
            "source_ids": ["SRC-006"],
            "reason": "The product explicitly avoids guarantees and uses abstention/uncertainty."
        },
    ]
    if domain == "healthcare":
        base[2]["text"] = "Medication and treatment decisions require qualified human clinical judgment."
    return base

SOURCES = [
    {"id": "SRC-001", "name": "ETHICAL AI Verification Policy", "type": "Platform policy",
     "authority": "High", "freshness": "Current", "independence": "Independent", "url": "local://policy/verification"},
    {"id": "SRC-002", "name": "Citation Integrity Policy", "type": "Platform policy",
     "authority": "High", "freshness": "Current", "independence": "Independent", "url": "local://policy/citations"},
    {"id": "SRC-003", "name": "Human Oversight Policy", "type": "Platform policy",
     "authority": "High", "freshness": "Current", "independence": "Independent", "url": "local://policy/human-oversight"},
    {"id": "SRC-004", "name": "Policy Version 2023 (illustrative)", "type": "Demo document",
     "authority": "Medium", "freshness": "Old", "independence": "Independent", "url": "local://demo/policy-2023"},
    {"id": "SRC-005", "name": "Policy Version 2026 (illustrative)", "type": "Demo document",
     "authority": "High", "freshness": "Current", "independence": "Independent", "url": "local://demo/policy-2026"},
    {"id": "SRC-006", "name": "No-Guarantee Safety Policy", "type": "Platform policy",
     "authority": "High", "freshness": "Current", "independence": "Independent", "url": "local://policy/no-guarantees"},
]

def evidence_for(claims: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for c in claims:
        for sid in c["source_ids"]:
            s = next(x for x in SOURCES if x["id"] == sid)
            out.append({
                "claim_id": c["id"],
                "source_id": sid,
                "source": s,
                "support": c["status"],
                "passage": f"Illustrative evidence associated with {c['id']}. Replace with retrieved source passages in production."
            })
    return out

class AnalyzeRequest(BaseModel):
    question: str = Field(min_length=1, max_length=12000)
    answer: str | None = None
    domain: str = "citizen"
    language: str = "en"
    human_available: bool = True

class ReviewRequest(BaseModel):
    analysis_id: str
    decision: str
    note: str = ""

class ChatRequest(BaseModel):
    question: str = Field(min_length=1, max_length=12000)
    domain: str = "citizen"
    language: str = "en"
    human_available: bool = True

async def provider_answer(question: str, domain: str, language: str) -> str:
    provider = os.getenv("AI_PROVIDER", "demo")
    key = os.getenv("AI_API_KEY", "")
    model = os.getenv("AI_MODEL", "")
    base = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
    if provider != "openai_compatible" or not key or not model:
        return demo_answer(question, domain, language)
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    system = (
        "You are an assistant inside ETHICAL AI. Give useful information, be explicit about uncertainty, "
        "do not claim certainty when evidence is unavailable, and do not present yourself as a doctor, lawyer, "
        "police officer or emergency service. Keep the response concise."
    )
    payload = {"model": model, "messages": [{"role": "system", "content": system},
                                              {"role": "user", "content": question}], "temperature": 0.2}
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(f"{base}/chat/completions", headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            return data["choices"][0]["message"]["content"]
    except Exception:
        return demo_answer(question, domain, language)

@app.get("/health")
def health():
    return {"status": "ok", "mode": os.getenv("AI_PROVIDER", "demo"), "timestamp": now()}

@app.get("/api/domains")
def domains():
    return DOMAINS

@app.get("/api/alerts")
def alerts():
    return ALERTS

@app.get("/api/emergency")
def emergency():
    return EMERGENCY_SERVICES

@app.get("/api/audit")
def audit():
    return list(reversed(AUDIT[-100:]))

@app.get("/api/reviews")
def reviews():
    return list(reversed(REVIEWS))

@app.post("/api/chat")
async def chat(req: ChatRequest):
    risk = risk_for(req.question, req.domain)
    answer = await provider_answer(req.question, req.domain, req.language)
    if risk in {"high", "critical"}:
        answer += "\n\nETHICAL AI safety note: this request may require qualified human judgment."
    log("assistant.response", {"domain": req.domain, "risk": risk})
    return {"answer": answer, "risk": risk, "human_required": risk in {"high", "critical"}}

@app.post("/api/analyze")
async def analyze(req: AnalyzeRequest):
    answer = req.answer or await provider_answer(req.question, req.domain, req.language)
    risk = risk_for(req.question + " " + answer, req.domain)
    claims = extract_claims(answer, req.domain)
    evidence = evidence_for(claims)
    status_counts = {}
    for c in claims:
        status_counts[c["status"]] = status_counts.get(c["status"], 0) + 1
    human_required = risk in {"high", "critical"} or any(c["status"] == "contradicted" for c in claims)
    human_available = req.human_available
    autonomy = "human_review" if human_required and human_available else (
        "safe_ai_fallback" if human_required else "ai_assisted"
    )
    analysis_id = str(uuid.uuid4())
    record = {
        "id": analysis_id,
        "question": req.question,
        "answer": answer,
        "domain": req.domain,
        "language": req.language,
        "risk": risk,
        "human_required": human_required,
        "human_available": human_available,
        "autonomy": autonomy,
        "claims": claims,
        "evidence": evidence,
        "sources": SOURCES,
        "status_counts": status_counts,
        "verification_strength": "strong" if sum(1 for c in claims if c["status"] == "supported") >= 3 else "mixed",
        "created_at": now(),
        "demo_mode": os.getenv("AI_PROVIDER", "demo") == "demo",
    }
    ANALYSES[analysis_id] = record
    if human_required:
        REVIEWS.append({
            "id": str(uuid.uuid4()),
            "analysis_id": analysis_id,
            "domain": req.domain,
            "risk": risk,
            "status": "pending" if human_available else "human_unavailable",
            "created_at": now(),
            "note": "Human review required by risk policy."
        })
    log("analysis.created", {"analysis_id": analysis_id, "risk": risk, "autonomy": autonomy})
    return record

@app.get("/api/analysis/{analysis_id}")
def get_analysis(analysis_id: str):
    if analysis_id not in ANALYSES:
        raise HTTPException(404, "Analysis not found")
    return ANALYSES[analysis_id]

@app.post("/api/review")
def review(req: ReviewRequest):
    for item in REVIEWS:
        if item["analysis_id"] == req.analysis_id:
            item["status"] = req.decision
            item["note"] = req.note
            item["reviewed_at"] = now()
            log("human.reviewed", {"analysis_id": req.analysis_id, "decision": req.decision})
            return item
    raise HTTPException(404, "Review not found")
