# Universal architecture

## Core

React/Vite frontend -> FastAPI backend -> AI provider -> Trust engine -> Evidence -> Risk -> Human review -> Audit.

## Domain strategy

Do not create ten separate applications. Use a common engine plus domain policy packs.

Each policy pack controls:
- source allowlists
- risk rules
- required evidence strength
- human review requirements
- retention/handling rules
- response language and UX

## Production evolution

Phase 1:
React + FastAPI + local demo engine.

Phase 2:
PostgreSQL + pgvector + real search/evidence providers + authentication.

Phase 3:
Redis/queue + background verification workers + object storage + observability.

Phase 4:
Multi-tenant enterprise SaaS + SSO/RBAC + private deployments + API gateway.

## Safety

The LLM must not be the source of truth. Retrieved content is untrusted data until validated. High-impact decisions should remain under authorized human control. Emergency contacts must be verified for the deployment geography.
