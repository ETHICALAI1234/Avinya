# 3-minute SIH demo script

## 1 — Problem (20 sec)

"AI can sound confident while containing unsupported claims, contradictions or unreliable citations. ETHICAL AI is the independent trust layer between AI output and human action."

## 2 — Universal assistant (25 sec)

Ask a normal question in English. Show the response. Explain that the user can verify it rather than blindly trusting it.

## 3 — Verification (45 sec)

Open Verify AI, load the demo answer, click Verify.

Show:
- claim extraction
- supported claim
- partial claim
- contradicted claim
- evidence
- source quality

Say: "We do not collapse an answer into one fake truth percentage. We expose the evidence chain claim by claim."

## 4 — Human control (35 sec)

Open Risk & Human Control. Show HIGH or CRITICAL and the human review path.

Toggle Human Control off and explain the safe AI fallback.

Say: "Our AI fills the gap when humans are unavailable, but it never hides when human judgment is required."

## 5 — Universal access (30 sec)

Open Voice & Languages and use Telugu or Hindi. Explain that verification happens after language understanding and before the final answer is trusted.

## 6 — Evidence graph (20 sec)

Open Evidence Graph. Explain Answer → Claim → Source → Status.

## 7 — Market (25 sec)

"We are not building another chatbot. The same trust engine can be exposed as an API and deployed for education, research, agriculture, healthcare, finance, government and enterprise AI."

## 8 — Close (10 sec)

"AI generates. ETHICAL AI verifies. Risk controls autonomy. Humans remain accountable."
